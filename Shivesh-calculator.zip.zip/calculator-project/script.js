const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");
let currentInput = "";

buttons.forEach((button) => {
  button.addEventListener("click", () => {
    const value = button.textContent;

    if (value === "C") {
      currentInput = "";
    } else if (value === "=") {
      try {
        if (currentInput.includes("/0")) {
          currentInput = "Error";
        } else {
          currentInput = eval(currentInput).toString();
        }
      } catch {
        currentInput = "Error";
      }
    } else {
      currentInput += value;
    }

    display.value = currentInput;
  });
});

// Keyboard input
document.addEventListener("keydown", (e) => {
  if (
    (e.key >= "0" && e.key <= "9") ||
    ["+", "-", "*", "/", "."].includes(e.key)
  ) {
    currentInput += e.key;
  } else if (e.key === "Enter") {
    try {
      if (currentInput.includes("/0")) {
        currentInput = "Error";
      } else {
        currentInput = eval(currentInput).toString();
      }
    } catch {
      currentInput = "Error";
    }
  } else if (e.key === "Backspace") {
    currentInput = currentInput.slice(0, -1);
  } else if (e.key === "Escape") {
    currentInput = "";
  }

  display.value = currentInput;
});
